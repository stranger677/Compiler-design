```markdown
# Intermediate Code Generator (TAC)

A compiler project that converts arithmetic expressions into Three-Address Code (TAC) using Flex and Bison on Windows.

## Features

- Converts expressions like `x = 3 + 5 * 2` to TAC
- Supports both integers and floating-point numbers
- Handles operator precedence and parentheses
- Provides meaningful error messages with line numbers

## Prerequisites

- Windows 10/11
- [WinFlexBison](https://github.com/lexxmark/winflexbison/releases)
- [MinGW-w64](https://sourceforge.net/projects/mingw-w64/) (GCC compiler)

## Installation

1. Install WinFlexBison and add to PATH
2. Install MinGW-w64 and add `gcc.exe` to PATH
3. Verify installations:
   ```cmd
   win_flex --version
   win_bison --version
   gcc --version
   ```

## How to Build & Run

1. Clone/download the project
2. Open Command Prompt in project folder
3. Build the compiler:
   ```cmd
   win_flex lexer.l
   win_bison -d parser.y
   gcc lex.yy.c parser.tab.c -o tac_gen.exe
   ```
4. Run with input file:
   ```cmd
   tac_gen.exe < input.txt
   ```

## Sample Input/Output

--input.txt--:
```c
price = 100;
discount = 20;
final = price - discount;
tax = final * 0.1;
```

--Output--:
```
price = 100
discount = 20
t1 = price - discount
final = t1
t2 = final * 0.10
tax = t2
```

## Project Structure

- `lexer.l` - Flex lexer rules
- `parser.y` - Bison grammar rules
- `input.txt` - Sample input file

## Troubleshooting

- --"command not found"--: Check PATH for win_flex/win_bison/gcc
- --Invalid character errors--: Ensure input uses only supported operators
- --Memory issues--: Rebuild if you modify grammar rules

## License

MIT License - Free for academic and personal use
```

Key features of this README:
1. --Windows-specific-- instructions (no Linux/bash commands)
2. --Minimal dependencies-- list
3. --Clear build steps-- using CMD
4. --Practical example-- showing input/output
5. --Troubleshooting-- for common issues
6. --Clean formatting-- with code blocks


